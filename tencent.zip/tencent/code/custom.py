
import keras
from keras.preprocessing.sequence import pad_sequences
from keras.callbacks import ModelCheckpoint,EarlyStopping
import numpy as np



class ParallelModelCheckpoint(ModelCheckpoint):
    def __init__(self,model,filepath, monitor='val_loss', verbose=0,
                 save_best_only=False, save_weights_only=False,
                 mode='auto', period=1):
        self.single_model = model
        super(ParallelModelCheckpoint,self).__init__(filepath, monitor, verbose,save_best_only, save_weights_only,mode, period)

    def set_model(self, model):
        super(ParallelModelCheckpoint,self).set_model(self.single_model)




class DataGenerator(keras.utils.Sequence):
    'Generates data for Keras'
    def __init__(self, onthoht_sparse,text,batch_size,numclass, shuffle=False):
        'Initialization'
        self.batch_size = batch_size
        self.onthoht_sparse = onthoht_sparse
        self.text = text
        self.n_classes = numclass
        self.shuffle = shuffle
        self.indexes = np.arange(len(self.text))

    def __len__(self):
        'Denotes the number of batches per epoch'
        return int(np.floor(len(self.text) / self.batch_size))

    def __getitem__(self, index):
        'Generate one batch of data'
        # Generate indexes of the batch
        indexs = self.indexes[index*self.batch_size:(index+1)*self.batch_size]
        # Generate data
        X1, X2 = self.__data_generation(indexs)
        return [X1,X2]


    def __data_generation(self,indexs):
        'Generates data containing batch_size samples' # X : (n_samples, *dim, n_channels)
        # Initialization
        X1, X2= [], []
        # Generate data
        for i in indexs:
            # Store sample
            x_onehot = self.onthoht_sparse[i, :].toarray()[0]
            x_text = self.text[i][:200]
            # Store class
            X1.append(x_onehot)
            X2.append(x_text)
        X1 = np.array(X1)
        X2 = pad_sequences(X2, maxlen=200, value=len(vocab))
        return X1, X2