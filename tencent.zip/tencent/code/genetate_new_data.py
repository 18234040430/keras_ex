import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
import pickle
from gensim.models import Word2Vec
from itertools import islice
from gensim.corpora import Dictionary
from gensim.models import TfidfModel


def get_new_data(data):
    cw = lambda x: [list(i.split(',')) for i in list(x.split('[sep]'))]
    data['sentences'] = data['text'].apply(cw)
    cw = lambda x: ','.join([j for i in x for j in i])
    data['words'] = data['sentences'].apply(cw)
    creative_list = []
    ad_id_list = []
    product_id_list = []
    product_category_list = []
    advertiser_id_list = []
    industry_list = []

    for _, row in data.iterrows():
        sentences = row['sentences']
        creative_str = ','.join(sentences[0])
        ad_id_str = ','.join(sentences[1])
        product_id_str = ','.join(sentences[2])
        product_category_str = ','.join(sentences[3])
        advertiser_id_str = ','.join(sentences[4])
        industry_str = ','.join(sentences[5])
        creative_list.append(creative_str)
        ad_id_list.append(ad_id_str)
        product_id_list.append(product_id_str)
        product_category_list.append(product_category_str)
        advertiser_id_list.append(advertiser_id_str)
        industry_list.append(industry_str)

    data = pd.DataFrame({'user_id': data['user_id'],
                         'text': data['text'],
                         'words': data['words'],
                         'creative_id': creative_list,
                         'ad_id': ad_id_list,
                         'product_id': product_id_list,
                         'product_category':product_category_list,
                         'advertiser_id': advertiser_id_list,
                         'industry': industry_list,
                         'types':data['types']
                         })

    return data



train = pd.read_csv('../data/train/train_data.csv')
test = pd.read_csv('../data/test/test_data.csv')
train['types'] = 'train'
test['types'] = 'test'
data = pd.concat([train,test])
data = get_new_data(data)
data = data.reset_index()


#生成muti-count-encode
cv = CountVectorizer()
wordlist = set([word for l in data['words'].values for word in l])
wordlist.remove('')
cv.fit(wordlist)
with open('../model/other/muti-count-encode.pickle', 'wb') as f:
    pickle.dump(cv, f)

#生成word2vec-encode


sentence = [i for t in data['sentences'].values for i in t]
model = Word2Vec(sentence, size=300, window=5, min_count=0, workers=60, sg=1,hs=1)
#model.save('../data/other/word2vec.model')
model.wv.save('../model/other/word2vec.wv')
#model = gensim.models.Word2Vec.load('../model/other/word2vec.txt')


def topk(t,thread,doc):
    return ','.join(list(islice([doc[w] for w,score in t],thread)))


def generate_keywords_text(data,key):
    t = data[key].values
    t = [i.split(',') for i in t]
    doc = Dictionary(t)
    corpus = [doc.doc2bow(i) for i in t]
    model = TfidfModel(corpus)
    return [topk(i,50,doc) for i in model[corpus]]

data['creative_id_key'] = generate_keywords_text(data,'creative_id')
data['ad_id_key'] = generate_keywords_text(data,'ad_id')
data['product_id_key'] = generate_keywords_text(data,'product_id')
data['product_category_key'] = generate_keywords_text(data,'product_category')
data['advertiser_id_key'] = generate_keywords_text(data,'advertiser_id')
data['industry_key'] = generate_keywords_text(data,'industry')
data.to_csv('../data/data.csv',index=False)
init_texts = []
top_key_texts = []
for _, row in data.iterrows():
    init_text = row['words']
    creative_id_key_text = row['creative_id_key']
    ad_id_key_text = row['ad_id_key']
    product_id_key_text = row['product_id_key']
    product_category_key_text = row['product_category_key']
    advertiser_id_key_text = row['advertiser_id_key']
    industry_key_text = row['industry_key']

    top_key_text = creative_id_key_text + ',' + ad_id_key_text + ',' + product_id_key_text + ',' + product_category_key_text + ',' + advertiser_id_key_text + ',' + industry_key_text
    init_texts.append(init_text)
    top_key_texts.append(top_key_text)

data = pd.DataFrame({'user_id':list(data['user_id'].values),'init_text':init_texts,'top_key_text':top_key_texts,'types':list(data['types'].values)})


train = data[data['types'] == 'train']
user = pd.read_csv('../data/train/user.csv')
train = pd.merge(train,user,on='user_id',how='left')

train.to_csv('../data/train/new_train.csv',index = False)

test = data[data['types'] == 'test']
test.to_csv('../data/test/new_test.csv',index = False)





