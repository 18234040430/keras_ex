import numpy as np
import pandas as pd




def get_ad_data(l):
    ad_data =pd.concat(l)
    ad_data = ad_data.drop_duplicates()
    return ad_data

def div_list(listTemp, n):
    for i in range(0, len(listTemp), n):
        yield listTemp[i:i + n]




def get_new_data(data):
    cw = lambda x: [list(i.split(',')) for i in list(x.split('[sep]'))]
    data['sentences'] = data['text'].apply(cw)
    cw = lambda x: [j for i in x for j in i]
    data['words'] = data['sentences'].apply(cw)
    return data


def get_new_data_set(data):
    cw = lambda x: [list(set(i.split(',')))  for i in list(x.split('[sep]'))]
    data['sentences'] = data['text'].apply(cw)
    cw = lambda x: [j for i in x for j in i]
    data['words'] = data['sentences'].apply(cw)
    return data