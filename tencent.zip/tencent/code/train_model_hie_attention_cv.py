import tensorflow as tf
import pickle
import hie_attention_model
from util import  *
from  sklearn.model_selection import StratifiedKFold
from keras.callbacks import ModelCheckpoint,EarlyStopping
from custom_op import  *
import keras




MAX_SENT_LENGTH = 100
MAX_SENTS = 6
EMBEDDING_DIM = 100
CLS = 'age'
NUM_CLASSES = 10


def word_to_seq(data,vocab):
    m = np.zeros((data.shape[0], MAX_SENTS, MAX_SENT_LENGTH), dtype='int32')
    for index,series in data.iterrows():
        sentences = series['sentences']
        for j,sent in enumerate(sentences):
            if j < MAX_SENTS:
                wordTokens = sent
                k = 0
                for _,word in enumerate(wordTokens):
                    if k<MAX_SENT_LENGTH:
                        m[index,j,k] = vocab[word]
                        k=k+1
                    else:
                        break
    return m




def run_cv(n_fload,data,label):

    data_split = StratifiedKFold(n_splits=n_fload, shuffle=True, random_state=1).split(data,label)
    for i, (train_index_list, test_index_list) in enumerate(data_split):
        x_train, x_test = data.iloc[train_index_list], data.iloc[test_index_list]
        label = keras.utils.to_categorical(train[CLS] - 1, num_classes=NUM_CLASSES)
        y_train,y_test = label[train_index_list],label[test_index_list]
        
        model = hie_attention_model.getmodel(embedding_dim=EMBEDDING_DIM, max_sent_length=MAX_SENT_LENGTH,
                                             max_sents=MAX_SENTS, vocab=vocab, numclass=NUM_CLASSES)
        file_path = '../model/' + CLS + '/06_09_weights+'+str(i)+'.best.hdf5'
        checkpoint = ModelCheckpoint(file_path, monitor='val_acc', verbose=1, save_best_only=True, mode='max',
                                     save_weights_only=True)
        early_stopping = EarlyStopping(monitor='val_acc', patience=1, verbose=1, mode='max')
        model.compile(loss='categorical_crossentropy',
                      optimizer = AdamW(),
                      metrics=['acc'])
        history = model.fit(x_train, y_train, validation_data=(x_test, y_test),
                            epochs=10, batch_size=50, callbacks=[checkpoint, early_stopping])
        K.clear_session()
        tf.reset_default_graph()


if __name__ == '__main__':


    train = pd.read_csv('../data/train/train_data.csv')
    user = pd.read_csv('../data/train/user.csv')

    # 加载字典
    with open('../model/other/muti-count-encode.pickle', 'rb') as f:
        muti_count_encode = pickle.load(f)

    vocab = muti_count_encode.vocabulary_
    train = get_new_data(train)
    train_data = word_to_seq(train, vocab)
    train = pd.merge(train, user, on='user_id', how='left')

    run_cv(5,train_data,label)






















