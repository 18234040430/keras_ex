import keras
from keras.preprocessing.text import Tokenizer
from keras.callbacks import EarlyStopping
from keras.callbacks import ModelCheckpoint
from keras.models import Sequential,Model
from keras.layers import *
from keras.preprocessing.sequence import pad_sequences
from keras.utils import multi_gpu_model
from keras.models import load_model
from keras.optimizers import Optimizer

from keras import backend as K

from gensim.models import Word2Vec
import numpy as np
import pandas as pd
import pickle
import os

from sklearn.model_selection import StratifiedKFold,KFold

MDEOL_NAME = 'word2vec_lstm'
FILE_NAME = 'data_text'
CLS = 'age'

# MAX_SENT_LENGTH = 100 0.459
MAX_SENT_LENGTH = 100
VOCAB_SIZE = 300000

BASE_PATH = '/mnt/wangshaoshuai3/TX_NEW/wss/'
PATH = BASE_PATH+'multi_input1/'+MDEOL_NAME+'/'

df = pd.read_csv(BASE_PATH+'data/train/' + FILE_NAME + '.csv')
# df = df.iloc[0:10000]

def mkdir(path):
    path=path.strip()
    path=path.rstrip('\\')
    isExists=os.path.exists(path)
 
    if not isExists:
        os.makedirs(path) 
        print(path+' 创建成功')
        return True
    else:
        print(path+' 目录已存在')

def data_preprocess(data,col_name):
    text_list = data[col_name]
    print('padding_size:',MAX_SENT_LENGTH)
    
    file = BASE_PATH+'tokenizer/model/data_text_tokenizer_'+col_name+'_'+str(MAX_SENT_LENGTH)+'.pickle'
    with open(file, 'rb') as f:
        tokenizer = pickle.load(f)
   
    x = tokenizer.texts_to_sequences(text_list)
    x = pad_sequences(x, maxlen = MAX_SENT_LENGTH)
    
    print('构建矩阵...')
    model_path = (BASE_PATH+'word2vec/model/'+str(MAX_SENT_LENGTH)+'/'+col_name+'/data_text_window5.model')
    print(model_path)
    model = Word2Vec.load(model_path)
    
#     index_word = tokenizer.index_word
#     embeddings_matrix = np.zeros((len(index_word) + 1,model.vector_size))#创建一个空的矩阵（储存多个数组）
#     for k,v in index_word.items():
#         try:
#             embeddings_matrix[k] = model.wv[v]
#         except:
#             print(k)

    index_word = tokenizer.index_word
    embeddings_matrix = np.zeros((VOCAB_SIZE + 1,model.vector_size))#创建一个空的矩阵（储存多个数组）
    for k,v in index_word.items():
        if k <= VOCAB_SIZE:
            try:
                embeddings_matrix[k] = model.wv[v]
            except:
                print(k)

    # 对类别变量进行编码
    if CLS == 'age':
        y = data['label'].apply(lambda x:x.split('_')[0]).astype('int')
    elif CLS == 'gender':
        y = data['label'].apply(lambda x:x.split('_')[1]).astype('int')
    else:
        y = data['label']
    
    y_labels = sorted(list(set(y)))
    print('y_labels',y_labels)
    num_labels = len(y_labels)
    y = keras.utils.to_categorical([y_labels.index(i) for i in y], num_labels)
 
    # vocab_size = len(tokenizer.word_index)
    vocab_size = VOCAB_SIZE
    
    return x, y, vocab_size, num_labels, embeddings_matrix

data1 = data_preprocess(df,'creative_id')
data3 = data_preprocess(df,'ad_id')
data6 = data_preprocess(df,'advertiser_id')

x1 = data1[0]
x3 = data3[0]
x6 = data6[0]

y = data1[1]

x1_vocab_size = data1[2]
x3_vocab_size = data3[2]
x6_vocab_size = data6[2]

num_labels = data1[3]

embeddings_matrix1 = data1[4]
embeddings_matrix3 = data3[4]
embeddings_matrix6 = data6[4]

def create_base_seqNetwork(input_dim,vocab_size,embeddings_matrix):
    m = Embedding(vocab_size+1, MAX_SENT_LENGTH , weights=[embeddings_matrix])(input_dim)
    m = Bidirectional(CuDNNLSTM(units=256,return_sequences=True))(m)
    return m

def get_model():
    input_1 = Input(shape=(x1.shape[1],))
    input_3 = Input(shape=(x3.shape[1],))
    input_6 = Input(shape=(x6.shape[1],))
    
    m1 = create_base_seqNetwork(input_1,x1_vocab_size,embeddings_matrix1)
    m3 = create_base_seqNetwork(input_3,x3_vocab_size,embeddings_matrix3)
    m6 = create_base_seqNetwork(input_6,x6_vocab_size,embeddings_matrix6)
    
    con = concatenate([m1, m3, m6],axis=-1)
    
    con = Dropout(0.2)(con)
    con = CuDNNLSTM(units=256,return_sequences=False)(con)
    con = Dense(512, activation='elu', kernel_regularizer=keras.regularizers.l2(0.001))(con)
    con = Dropout(0.2)(con) 
    
    main_output = Dense(num_labels,activation='softmax')(con)
    model = Model(inputs = [input_1,input_3,input_6],outputs = main_output)
    
    return model
    
def train():
    kfolder = KFold(n_splits=5,random_state=1)
    index = 1
    for train, test in kfolder.split(x1,y):
        model = get_model()
        model = multi_gpu_model(model, gpus=2)
#         adam = keras.optimizers.Adam(lr=0.001, beta_1=0.9, beta_2=0.999, epsilon=1e-08, decay=0.0001)
        model.compile(loss='categorical_crossentropy', optimizer = 'adam' , metrics=['accuracy'])
        es = EarlyStopping(monitor='val_acc',mode='max',patience=3)
        
        # 保存模型文件
        MODEL_SAVE_PATH = PATH + 'model/' + CLS + '/' + str(MAX_SENT_LENGTH) + '/'
        mkdir(MODEL_SAVE_PATH)
        MODEL_SAVE_PATH = MODEL_SAVE_PATH+'/mutil_input_'+ MDEOL_NAME + '_' + FILE_NAME + '_' + str(index) + '_model.h5'
        checkpoint = ModelCheckpoint(filepath = MODEL_SAVE_PATH, monitor='val_acc',mode='max' ,save_best_only='True')
        
        print('开始训练......')
        history = model.fit([x1[train],x3[train],x6[train]], y[train],
                  batch_size=256,
                  epochs=20,
                  callbacks=[es,checkpoint],
                  validation_data=([x1[test],x3[test],x6[test]], y[test]))
        
        # 日志保存
        LOG_SAVE_PATH = PATH + 'log/' + str(MAX_SENT_LENGTH) + '/'
        mkdir(LOG_SAVE_PATH)
        LOG_SAVE_PATH = LOG_SAVE_PATH + CLS + '_val_acc_' + str(index) +'.txt'
        np.savetxt(LOG_SAVE_PATH,history.history['val_acc'])   
        print('日志保存成功')
        
        index = index + 1
if __name__ == '__main__':
    try:
        train()
    except Exception as err:
        print(err)
        