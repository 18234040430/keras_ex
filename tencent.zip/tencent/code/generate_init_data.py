from util import  *
import time
from multiprocessing import Pool


def to_text(user_id_list):
    data = mergedata
    cols = ['creative_id','ad_id','product_id','product_category','advertiser_id','industry']
    texts=[]
    for user_id in user_id_list:
        temp = data[data.index == user_id].sort_values('time')
        text = ''
        for col in cols:
            l = temp[col].values
            l = [col+str(i) for i in l]
            text+=','.join(l)+'[sep]'
        texts.append(text)
    print('end')
    return pd.DataFrame({'user_id':user_id_list,'text':texts})

def loaddata(path='../data/'):
    # 加载数据
    user_data = pd.read_csv(path+'train/user.csv')
    ad_data_train = pd.read_csv(path+'train/ad.csv')
    ad_data_test = pd.read_csv(path+'test/ad.csv')
    click_log_data_train = pd.read_csv(path+'train/click_log.csv')
    click_log_data_test = pd.read_csv(path+'test/click_log.csv')
    click_log_data = {'click_log_data_train': click_log_data_train, 'click_log_data_test': click_log_data_test}

    # 数据清洗
    ad_data = get_ad_data([ad_data_train, ad_data_test])
    ad_data['product_id'][ad_data['product_id'] == '\\N'] = 99999
    ad_data['industry'][ad_data['industry'] == '\\N'] = 99999

    return click_log_data,ad_data






if __name__=='__main__':
    # mergedata
    l = ['click_log_data_train','click_log_data_test']
    click_log_data,ad_data = loaddata()
    for i in l:
        mergedata = pd.merge(click_log_data[i], ad_data, on='creative_id', how='left')
        mergedata = mergedata.set_index(['user_id'])
        st = time.time()
        data = mergedata
        n = 32
        pool =Pool(processes=n)
        result = []
        user_list = list(set(data.index))
        l = div_list(user_list,900000//n)
        l = list(l)
        res = pool.map(to_text,l)
        pool.close()
        pool.join()
        ed = time.time()
        print(ed-st)
        data = pd.concat(res)
        data = data[['user_id', 'text']]
        if 'train' in i:
            data.to_csv('../data/train_data.csv', index=False)
        else:
            data.to_csv('../data/test_data.csv', index=False)