
from keras.layers import *
from keras.models import Model
import keras.backend as K
from keras import regularizers
class AttentionLayer(Layer):
    def __init__(self, **kwargs):
        super(AttentionLayer, self).__init__(**kwargs)

    def build(self, input_shape):
        assert len(input_shape) == 3
        # W.shape = (time_steps, time_steps)
        self.W = self.add_weight(name='att_weight',
                                 shape=(input_shape[2], input_shape[2]),
                                 initializer='uniform',
                                 trainable=True)
        self.UW = self.add_weight(name='random_weight', shape=[input_shape[2], 1],
                                  initializer='random_normal',
                                  trainable=True)
        super(AttentionLayer, self).build(input_shape)

    def call(self, inputs, mask=None):
        x = inputs
        U = K.tanh(K.dot(x, self.W))
        a = K.softmax(K.squeeze(K.dot(U, self.UW), axis=-1))

        a = K.expand_dims(a, axis=-1)
        outputs = a * inputs

        outputs = K.sum(outputs, axis=1)
        return outputs

    def compute_output_shape(self, input_shape):
        return input_shape[0], input_shape[2]



def getmodel(embedding_dim,max_sents,max_sent_length,vocab,numclass):
    embedding_layer = Embedding(len(vocab) + 1, embedding_dim, input_length=300, trainable=True)
    sentence_input = Input(shape=(max_sent_length,), dtype='int32')
    embedded_sequences = embedding_layer(sentence_input)
    l_lstm = Bidirectional(LSTM(128, return_sequences=True))(embedded_sequences)
    l_dense = TimeDistributed(Dense(128))(l_lstm)
    l_att = AttentionLayer()(l_dense)
    sentEncoder = Model(sentence_input, l_att)

    review_input = Input(shape=(max_sents, max_sent_length), dtype='int32')
    review_encoder = TimeDistributed(sentEncoder)(review_input)
    l_lstm_sent = Bidirectional(LSTM(128, return_sequences=True))(review_encoder)
    l_dense_sent = TimeDistributed(Dense(200))(l_lstm_sent)
    l_att_sent = AttentionLayer()(l_dense_sent)
    forward_t = Dense(128,activation='relu')(l_att_sent)
    forward_t_drop = Dropout(0.5)(forward_t)
    preds = Dense(numclass, activation='softmax', kernel_regularizer=regularizers.l2(0.01)
                  ,activity_regularizer=regularizers.l1(0.01)
                  )(forward_t_drop)
    model = Model(review_input, preds)
    model.summary()
    return model