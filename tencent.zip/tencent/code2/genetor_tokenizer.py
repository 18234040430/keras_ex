import  pandas as pd
import  pickle
from keras.preprocessing.text import Tokenizer


def get_new_data(data):
    cw = lambda x: [list(i.split(',')) for i in list(x.split('[sep]'))]
    data['sentences'] = data['text'].apply(cw)
    cw = lambda x: [j for i in x for j in i]
    data['words'] = data['sentences'].apply(cw)
    return data





train = pd.read_csv('../data/train/train_data.csv')
test = pd.read_csv('../data/test/test_data.csv')
data = pd.concat([train,test])
data = get_new_data(data)
tokenizer=Tokenizer()  #创建一个Tokenizer对象
    #fit_on_texts函数可以将输入的文本中的每个词编号，编号是根据词频的，词频越大，编号越小
tokenizer.fit_on_texts(data['words'])
with open('../model/other/tokenizer.pickle', 'wb') as f:
    pickle.dump(tokenizer, f)
