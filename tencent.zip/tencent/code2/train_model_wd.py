#加载训练数据
import  pandas as pd
import pickle
import gensim
from sklearn.model_selection import train_test_split
from  keras.utils import  multi_gpu_model
from  model_wd import *
from  custom import  *

CLS = 'age'
NUM_CLASSES = 10




train = pd.read_csv('../data/train/new_train.csv')
train_data = train[['init_text','top_key_text']]
label = train[CLS]

x_train, x_test, y_train, y_test = train_test_split(train_data,label.values,test_size=0.1)

#加载字典
with open('../model/other/muti-count-encode.pickle', 'rb') as f:
    muti_count_encode = pickle.load(f)

vocab=muti_count_encode.vocabulary_



#生成onthot稀疏编码
init_text_train = x_train['init_text'].values
onthoht_sparse_train = muti_count_encode.transform(init_text_train)

init_text_test = x_test['init_text'].values
onthoht_sparse_test = muti_count_encode.transform(init_text_test)

ONEHOT_LEN = onthoht_sparse_train.shape[1]



#将text转换为编码
topk_text_train = x_train['top_key_text'].values
topk_text_train = [i.split(',') for i in topk_text_train]
def transformer_code(vocab,t):
    return [vocab[word] for word in t if word !='']

topk_text_train = [transformer_code(vocab,i) for i in topk_text_train]

topk_text_test = x_test['top_key_text'].values
topk_text_test = [i.split(',') for i in topk_text_test]
topk_text_test = [transformer_code(vocab,i) for i in topk_text_test]


#生成word2vec编码
embedding = np.random.rand(len(vocab)+1,300)
word_vectors = gensim.models.KeyedVectors.load('../model/other/word2vec.txt',mmap='r')
for key in vocab.keys():
    try:
        indexs = vocab[key]
        embedding[indexs] = word_vectors.wv[key]
    except Exception:
        print("error:"+key)
        pass





'''


def batch_generator(onthoht_sparse,text,label,batch_size,numclass):

    while(True):
        idx = np.arange(len(text))
        np.random.shuffle(idx)
        X1,X2,Y=[],[],[]
        np.random.shuffle(idx)
        for i in idx:
            x_onehot = onthoht_sparse[i, :].toarray()[0]
            x_text = text[i][:200]
            y = keras.utils.to_categorical(label[i]-1, num_classes=numclass)
            X1.append(x_onehot)
            X2.append(x_text)
            Y.append(y)
            if len(X1) == batch_size or i == idx[-1]:
                X1 = np.array(X1)
                X2 =pad_sequences(X2, maxlen=200,value=len(vocab))
                yield [X1, X2], [Y]
                X1 = []
                X2 = []
                Y = []

'''






train_model = get_model(embedding,vocab,NUM_CLASSES,ONEHOT_LEN)
parallel_model = multi_gpu_model(train_model, gpus=2)
parallel_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
file_path='../model/'+CLS+'/06_08_weights.best.hdf5'
checkpoint= ParallelModelCheckpoint(train_model,filepath=file_path, monitor='val_accuracy', verbose=1, save_best_only=True, mode='max',save_weights_only = True)
early_stopping = EarlyStopping(monitor='val_accuracy', patience=3, verbose=1, mode='max')
trainD = DataGenerator(onthoht_sparse_train,topk_text_train,y_train,batch_size=10,numclass=10)
testD = DataGenerator(onthoht_sparse_test,topk_text_test,y_test,batch_size=10,numclass=10,shuffle = True)
parallel_model.fit_generator(trainD,
                            callbacks=[early_stopping,checkpoint],
                            validation_steps=len(topk_text_test),
                            epochs=10,
                            validation_data=testD,
                            use_multiprocessing=False,
                            workers=20
                          )
