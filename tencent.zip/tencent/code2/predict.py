#加载训练数据
import  pandas as pd
import pickle
import gensim
import numpy as np
from keras.callbacks import ModelCheckpoint,EarlyStopping
from sklearn.model_selection import train_test_split
from keras.layers import *
from keras.models import Model
import keras.backend as K
from  keras.utils import  multi_gpu_model
import keras
from keras.preprocessing.sequence import pad_sequences

CLS = 'age'
NUM_CLASSES = 10


test = pd.read_csv('../data/test/new_test.csv')
test = test.head(100)
test_data = test[['init_text','top_key_text']].head(100)


#加载字典
with open('../model/other/muti-count-encode.pickle', 'rb') as f:
    muti_count_encode = pickle.load(f)

vocab=muti_count_encode.vocabulary_



#生成onthot稀疏编码
init_text = test['init_text'].values
onthoht_sparse = muti_count_encode.transform(init_text)
ONEHOT_LEN = onthoht_sparse.shape[1]

#将text转换为编码
topk_text = test['top_key_text'].values
topk_text = [i.split(',') for i in topk_text]
def transformer_code(vocab,t):
    return [vocab[word] for word in t if word !='']

topk_text = [transformer_code(vocab,i) for i in topk_text]

#生成word2vec编码
embedding = np.random.rand(len(vocab)+1,100)
def transfomer(x):
    return K.cast(x,'float32')


def get_model(embedding_weight,vocab,numclass,onehot_len):

    #wide
    one_hot_input = Input(shape=(onehot_len,),dtype= 'int32')


    #deep
    main_input = Input(shape=(200,), dtype='float32')
    # 词嵌入（使用预训练的词向量）
    embedder = Embedding(len(vocab) + 1, 100, input_length=200, trainable=True,weights=[embedding_weight])
    embed = embedder(main_input)
    # 词窗大小分别为3,4,5
    cnn1 = Conv1D(256, 3, padding='same', strides=1, activation='relu')(embed)
    cnn1 = MaxPooling1D(pool_size=48)(cnn1)
    cnn2 = Conv1D(256, 4, padding='same', strides=1, activation='relu')(embed)
    cnn2 = MaxPooling1D(pool_size=48)(cnn2)
    cnn3 = Conv1D(256, 5, padding='same', strides=1, activation='relu')(embed)
    cnn3 = MaxPooling1D(pool_size=48)(cnn3)
    # 合并三个模型的输出向量
    cnn = concatenate([cnn1, cnn2, cnn3], axis=-1)
    flat = Flatten()(cnn)
    cnn_drop = Dropout(0.5)(flat)

    #联合
    one_hot_input_f = Lambda(transfomer)(one_hot_input)
    concat = concatenate([one_hot_input_f, cnn_drop])
    main_output = Dense(numclass, activation='softmax')(concat)
    model = Model(inputs=[one_hot_input,main_input], outputs=main_output)

    return model



class ParallelModelCheckpoint(ModelCheckpoint):
    def __init__(self,model,filepath, monitor='val_loss', verbose=0,
                 save_best_only=False, save_weights_only=False,
                 mode='auto', period=1):
        self.single_model = model
        super(ParallelModelCheckpoint,self).__init__(filepath, monitor, verbose,save_best_only, save_weights_only,mode, period)

    def set_model(self, model):
        super(ParallelModelCheckpoint,self).set_model(self.single_model)




class DataGenerator(keras.utils.Sequence):
    'Generates data for Keras'
    def __init__(self, onthoht_sparse,text,batch_size,numclass, shuffle=False):
        'Initialization'
        self.batch_size = batch_size
        self.onthoht_sparse = onthoht_sparse
        self.text = text
        self.n_classes = numclass
        self.shuffle = shuffle
        self.indexes = np.arange(len(self.text))

    def __len__(self):
        'Denotes the number of batches per epoch'
        return int(np.floor(len(self.text) / self.batch_size))

    def __getitem__(self, index):
        'Generate one batch of data'
        # Generate indexes of the batch
        indexs = self.indexes[index*self.batch_size:(index+1)*self.batch_size]
        # Generate data
        X1, X2 = self.__data_generation(indexs)
        return [X1,X2]


    def __data_generation(self,indexs):
        'Generates data containing batch_size samples' # X : (n_samples, *dim, n_channels)
        # Initialization
        X1, X2= [], []
        # Generate data
        for i in indexs:
            # Store sample
            x_onehot = self.onthoht_sparse[i, :].toarray()[0]
            x_text = self.text[i][:200]
            # Store class
            X1.append(x_onehot)
            X2.append(x_text)
        X1 = np.array(X1)
        X2 = pad_sequences(X2, maxlen=200, value=len(vocab))
        return X1, X2

preD = DataGenerator(onthoht_sparse,topk_text,batch_size=10,numclass=10)
train_model = get_model(embedding,vocab,NUM_CLASSES,ONEHOT_LEN)
train_model.load_weights('../model/'+CLS+'/05_27_weights.best.hdf5')
#parallel_model = multi_gpu_model(train_model, gpus=2)
#parallel_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])



#p = parallel_model.predict_generator(preD, verbose=1)
train_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
p = train_model.predict_generator(preD, verbose=1)
y_predict_age = np.argmax(p, axis=1)
result = pd.DataFrame({'user_id':test['user_id'],'predicted_age':y_predict_age+1})
result['predicted_age'] = result['predicted_age'].astype('int')
result = result[['user_id','predicted_age']]
result.to_csv('../result/submission_test2.csv',index=False)
