import keras
import pickle
from sklearn.model_selection import train_test_split
from keras.callbacks import ModelCheckpoint,EarlyStopping
import hie_attention_model
from util import  *

MAX_SENT_LENGTH = 100
MAX_SENTS = 6
EMBEDDING_DIM = 100
CLS = 'gender'
NUM_CLASSES = 2


def word_to_seq(data,vocab):
    m = np.zeros((data.shape[0], MAX_SENTS, MAX_SENT_LENGTH), dtype='int32')
    for index,series in data.iterrows():
        sentences = series['sentences']
        for j,sent in enumerate(sentences):
            if j < MAX_SENTS:
                wordTokens = sent
                k = 0
                for _,word in enumerate(wordTokens):
                    if k<MAX_SENT_LENGTH:
                        m[index,j,k] = vocab[word]
                        k=k+1
                    else:
                        break
    return m


train = pd.read_csv('../data/train/train_data.csv')
test = pd.read_csv('../data/test/test_data.csv')
user = pd.read_csv('../data/train/user.csv')

#加载字典
with open('../model/other/muti-count-encode.pickle', 'rb') as f:
    muti_count_encode = pickle.load(f)

vocab=muti_count_encode.vocabulary_




train = get_new_data(train)

train_data = word_to_seq(train,vocab)
train = pd.merge(train,user,on='user_id',how='left')
x_train, x_test, y_train, y_test = train_test_split(train_data, keras.utils.to_categorical(train[CLS]-1, num_classes=NUM_CLASSES), test_size=0.1)




model = hie_attention_model.getmodel(embedding_dim=EMBEDDING_DIM,max_sent_length=MAX_SENT_LENGTH,max_sents=MAX_SENTS,vocab = vocab,numclass=NUM_CLASSES)

file_path='../model/'+CLS+'/05_16_weights.best.hdf5'
checkpoint= ModelCheckpoint(file_path, monitor='val_acc', verbose=1, save_best_only=True, mode='max',save_weights_only = True)
early_stopping = EarlyStopping(monitor='val_acc', patience=1, verbose=1, mode='max')


model.compile(loss='categorical_crossentropy',
              optimizer='adam',
              metrics=['acc'])
history = model.fit(x_train, y_train, validation_data=(x_test, y_test),
          epochs=10, batch_size=50,callbacks = [checkpoint,early_stopping])

print(history)










