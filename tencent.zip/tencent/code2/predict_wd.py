#加载训练数据
import  pandas as pd
import pickle
from keras.layers import *
from custom import  *
from model_wd import  *
import  gensim




CLS = 'age'
NUM_CLASSES = 10


test = pd.read_csv('../data/test/new_test.csv')
test = test.head(100)
test_data = test[['init_text','top_key_text']]


#加载字典
with open('../model/other/muti-count-encode.pickle', 'rb') as f:
    muti_count_encode = pickle.load(f)

vocab=muti_count_encode.vocabulary_



#生成onthot稀疏编码
init_text = test['init_text'].values
onthoht_sparse = muti_count_encode.transform(init_text)
ONEHOT_LEN = onthoht_sparse.shape[1]

#将text转换为编码
topk_text = test['top_key_text'].values
topk_text = [i.split(',') for i in topk_text]
def transformer_code(vocab,t):
    return [vocab[word] for word in t if word !='']

topk_text = [transformer_code(vocab,i) for i in topk_text]

#生成word2vec编码
embedding = np.random.rand(len(vocab)+1,300)
word_vectors = gensim.models.KeyedVectors.load('../model/other/word2vec.txt',mmap='r')
for key in vocab.keys():
    try:
        indexs = vocab[key]
        embedding[indexs] = word_vectors.wv[key]
    except Exception:
        print("error:"+key)
        pass

preD = DataGenerator(onthoht_sparse,topk_text,batch_size=10,numclass=10)
train_model = get_model(embedding,vocab,NUM_CLASSES,ONEHOT_LEN)
train_model.load_weights('../model/'+CLS+'/06_08_weights.best.hdf5')
train_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
p = train_model.predict_generator(preD, verbose=1)
y_predict_age = np.argmax(p, axis=1)
result = pd.DataFrame({'user_id':test['user_id'],'predicted_age':y_predict_age+1})
result['predicted_age'] = result['predicted_age'].astype('int')
result = result[['user_id','predicted_age']]
result.to_csv('../result/submission_test.csv',index=False)