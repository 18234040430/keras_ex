import pickle
import  hie_attention_model
from keras import backend as K
from  util import  *


MAX_SENT_LENGTH = 100
MAX_SENTS = 6
EMBEDDING_DIM = 100


def word_to_seq(data,vocab):
    m = np.zeros((data.shape[0], MAX_SENTS, MAX_SENT_LENGTH), dtype='int32')
    for index,series in data.iterrows():
        sentences = series['sentences']
        for j,sent in enumerate(sentences):
            if j < MAX_SENTS:
                wordTokens = sent
                k = 0
                for _,word in enumerate(wordTokens):
                    if k<MAX_SENT_LENGTH:
                        m[index,j,k] = vocab[word]
                        k=k+1
                    else:
                        break
    return m

#加载数据
test = pd.read_csv('../data/test/test_data.csv')
#加载编码器
with open('../model/other/tokenizer.pickle', 'rb') as f:
    tokenizer = pickle.load(f)

vocab=tokenizer.word_index
test = get_new_data(test)
test_data = word_to_seq(test,vocab)

#加载年龄模型并预测
model = hie_attention_model.getmodel(embedding_dim=EMBEDDING_DIM,max_sent_length=MAX_SENT_LENGTH,max_sents=MAX_SENTS,vocab = vocab,numclass=10)
model.load_weights('../model/age/05_16_weights.best.hdf5')
model.compile(loss='categorical_crossentropy',
              optimizer='adam',
              metrics=['acc'])
p = model.predict(test_data)
y_predict_age = np.argmax(p, axis=1)

K.clear_session()


#加载性别模型并预测

model = hie_attention_model.getmodel(embedding_dim=EMBEDDING_DIM,max_sent_length=MAX_SENT_LENGTH,max_sents=MAX_SENTS,vocab = vocab,numclass=2)
model.load_weights('../model/gender/05_16_weights.best.hdf5')
model.compile(loss='categorical_crossentropy',
              optimizer='adam',
              metrics=['acc'])
p = model.predict(test_data)
y_predict_gender = np.argmax(p, axis=1)


#输出结果
result = pd.DataFrame({'user_id':test['user_id'],'predicted_age':y_predict_age+1,'predicted_gender':y_predict_gender+1})
result['predicted_gender'] = result['predicted_gender'].astype('int')
result['predicted_age'] = result['predicted_age'].astype('int')
result = result[['user_id','predicted_age','predicted_gender']]
result.to_csv('../result/submission_0516.csv',index=False)





